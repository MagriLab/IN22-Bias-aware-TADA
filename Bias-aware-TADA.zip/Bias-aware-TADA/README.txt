# Bias-aware-TADA
Bias-aware real-time thermoacoustic Data Assimilation. 

Running main.m returns figure 4 in [1].

The codes are similar to the bias-aware simulations in Real-time-TA-DA but fixed the tau assimilation inconsistency.


---------------------------------------------------------

[1] Nóvoa, A., Racca, A. & Magri, L. 2022. Bias-aware thermoacoustic data assimilation. In 51st International Congress and Exposition on Noise Control Engineering—Internoise 2022.
